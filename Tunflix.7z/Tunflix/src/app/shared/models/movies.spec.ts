import { Movies } from './movies';

describe('Movies', () => {
  it('should create an instance', () => {
    expect(new Movies()).toBeTruthy();
  });
});

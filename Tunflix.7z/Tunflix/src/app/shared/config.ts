export const Config = {
  apiKey: '82ed0e0e4758949182988deb81145ba9',
  apiUrl: 'https://api.themoviedb.org/3/movie/',
  search: 'https://api.themoviedb.org/3/search/movie?api_key=82ed0e0e4758949182988deb81145ba9&language=en-US&page=1&include_adult=false&&query='
}
